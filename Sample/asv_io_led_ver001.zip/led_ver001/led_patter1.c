//LED�C���~�l�[�V�����p�^�[�����̂P
//1����_���A1�������


extern unsigned char led_duty[8];	//LED��duty��ݒ�(0�ŏ����A100�őS��)
extern int led_put_counter;

void led_put_pattern1(void)
{
	led_put_counter++;
	if(led_put_counter >= 400)
		led_put_counter = 0;

	if(led_put_counter < 10)
	{
		led_duty[0] = led_put_counter;
	}
	else if(led_put_counter < 20)
	{
		led_duty[0] = led_put_counter;
		led_duty[1] = led_put_counter-10;
	}
	else if(led_put_counter < 30)
	{
		led_duty[0] = led_put_counter;
		led_duty[1] = led_put_counter-10;
		led_duty[2] = led_put_counter-20;
	}
	else if(led_put_counter < 40)
	{
		led_duty[0] = led_put_counter;
		led_duty[1] = led_put_counter-10;
		led_duty[2] = led_put_counter-20;
		led_duty[3] = led_put_counter-30;
	}
	else if(led_put_counter < 50)
	{
		led_duty[0] = led_put_counter;
		led_duty[1] = led_put_counter-10;
		led_duty[2] = led_put_counter-20;
		led_duty[3] = led_put_counter-30;
		led_duty[4] = led_put_counter-40;
	}
	else if(led_put_counter < 60)
	{
		led_duty[0] = led_put_counter;
		led_duty[1] = led_put_counter-10;
		led_duty[2] = led_put_counter-20;
		led_duty[3] = led_put_counter-30;
		led_duty[4] = led_put_counter-40;
		led_duty[5] = led_put_counter-50;
	}
	else if(led_put_counter < 70)
	{
		led_duty[0] = led_put_counter;
		led_duty[1] = led_put_counter-10;
		led_duty[2] = led_put_counter-20;
		led_duty[3] = led_put_counter-30;
		led_duty[4] = led_put_counter-40;
		led_duty[5] = led_put_counter-50;
		led_duty[6] = led_put_counter-60;
	}
	else if(led_put_counter < 100)
	{
		led_duty[0] = led_put_counter;
		led_duty[1] = led_put_counter-10;
		led_duty[2] = led_put_counter-20;
		led_duty[3] = led_put_counter-30;
		led_duty[4] = led_put_counter-40;
		led_duty[5] = led_put_counter-50;
		led_duty[6] = led_put_counter-60;
		led_duty[7] = led_put_counter-70;
	}
	else if(led_put_counter < 110)
	{
		led_duty[1] = led_put_counter-10;
		led_duty[2] = led_put_counter-20;
		led_duty[3] = led_put_counter-30;
		led_duty[4] = led_put_counter-40;
		led_duty[5] = led_put_counter-50;
		led_duty[6] = led_put_counter-60;
		led_duty[7] = led_put_counter-70;
	}
	else if(led_put_counter < 120)
	{
		led_duty[2] = led_put_counter-20;
		led_duty[3] = led_put_counter-30;
		led_duty[4] = led_put_counter-40;
		led_duty[5] = led_put_counter-50;
		led_duty[6] = led_put_counter-60;
		led_duty[7] = led_put_counter-70;
	}
	else if(led_put_counter < 130)
	{
		led_duty[3] = led_put_counter-30;
		led_duty[4] = led_put_counter-40;
		led_duty[5] = led_put_counter-50;
		led_duty[6] = led_put_counter-60;
		led_duty[7] = led_put_counter-70;
	}
	else if(led_put_counter < 140)
	{
		led_duty[4] = led_put_counter-40;
		led_duty[5] = led_put_counter-50;
		led_duty[6] = led_put_counter-60;
		led_duty[7] = led_put_counter-70;
	}
	else if(led_put_counter < 150)
	{
		led_duty[5] = led_put_counter-50;
		led_duty[6] = led_put_counter-60;
		led_duty[7] = led_put_counter-70;
	}
	else if(led_put_counter < 160)
	{
		led_duty[6] = led_put_counter-60;
		led_duty[7] = led_put_counter-70;
	}
	else if(led_put_counter < 170)
	{
		led_duty[7] = led_put_counter-70;
	}
	else if(led_put_counter < 200)
	{
	}
	else if(led_put_counter < 210)
	{
		led_duty[0] = 300 - led_put_counter;	
	}
	else if(led_put_counter < 220)
	{
		led_duty[0] = 300 - led_put_counter;	
		led_duty[1] = 310 - led_put_counter;	
	}
	else if(led_put_counter < 230)
	{
		led_duty[0] = 300 - led_put_counter;	
		led_duty[1] = 310 - led_put_counter;	
		led_duty[2] = 320 - led_put_counter;	
	}
	else if(led_put_counter < 240)
	{
		led_duty[0] = 300 - led_put_counter;	
		led_duty[1] = 310 - led_put_counter;	
		led_duty[2] = 320 - led_put_counter;	
		led_duty[3] = 330 - led_put_counter;	
	}
	else if(led_put_counter < 250)
	{
		led_duty[0] = 300 - led_put_counter;	
		led_duty[1] = 310 - led_put_counter;	
		led_duty[2] = 320 - led_put_counter;	
		led_duty[3] = 330 - led_put_counter;	
		led_duty[4] = 340 - led_put_counter;	
	}
	else if(led_put_counter < 260)
	{
		led_duty[0] = 300 - led_put_counter;	
		led_duty[1] = 310 - led_put_counter;	
		led_duty[2] = 320 - led_put_counter;	
		led_duty[3] = 330 - led_put_counter;	
		led_duty[4] = 340 - led_put_counter;	
		led_duty[5] = 350 - led_put_counter;	
	}
	else if(led_put_counter < 270)
	{
		led_duty[0] = 300 - led_put_counter;	
		led_duty[1] = 310 - led_put_counter;	
		led_duty[2] = 320 - led_put_counter;	
		led_duty[3] = 330 - led_put_counter;	
		led_duty[4] = 340 - led_put_counter;	
		led_duty[5] = 350 - led_put_counter;	
		led_duty[6] = 360 - led_put_counter;	
	}
	else if(led_put_counter < 300)
	{
		led_duty[0] = 300 - led_put_counter;	
		led_duty[1] = 310 - led_put_counter;	
		led_duty[2] = 320 - led_put_counter;	
		led_duty[3] = 330 - led_put_counter;	
		led_duty[4] = 340 - led_put_counter;	
		led_duty[5] = 350 - led_put_counter;	
		led_duty[6] = 360 - led_put_counter;	
		led_duty[7] = 370 - led_put_counter;	
	}
	else if(led_put_counter < 310)
	{
		led_duty[0] = 0;
		led_duty[1] = 310 - led_put_counter;	
		led_duty[2] = 320 - led_put_counter;	
		led_duty[3] = 330 - led_put_counter;	
		led_duty[4] = 340 - led_put_counter;	
		led_duty[5] = 350 - led_put_counter;	
		led_duty[6] = 360 - led_put_counter;	
		led_duty[7] = 370 - led_put_counter;	
	}
	else if(led_put_counter < 320)
	{
		led_duty[1] = 0;
		led_duty[2] = 320 - led_put_counter;	
		led_duty[3] = 330 - led_put_counter;	
		led_duty[4] = 340 - led_put_counter;	
		led_duty[5] = 350 - led_put_counter;	
		led_duty[6] = 360 - led_put_counter;	
		led_duty[7] = 370 - led_put_counter;	
	}
	else if(led_put_counter < 330)
	{
		led_duty[2] = 0;
		led_duty[3] = 330 - led_put_counter;	
		led_duty[4] = 340 - led_put_counter;	
		led_duty[5] = 350 - led_put_counter;	
		led_duty[6] = 360 - led_put_counter;	
		led_duty[7] = 370 - led_put_counter;	
	}
	else if(led_put_counter < 340)
	{
		led_duty[3] = 0;
		led_duty[4] = 340 - led_put_counter;	
		led_duty[5] = 350 - led_put_counter;	
		led_duty[6] = 360 - led_put_counter;	
		led_duty[7] = 370 - led_put_counter;	
	}
	else if(led_put_counter < 350)
	{
		led_duty[4] = 0;
		led_duty[5] = 350 - led_put_counter;	
		led_duty[6] = 360 - led_put_counter;	
		led_duty[7] = 370 - led_put_counter;	
	}
	else if(led_put_counter < 360)
	{
		led_duty[5] = 0;
		led_duty[6] = 360 - led_put_counter;	
		led_duty[7] = 370 - led_put_counter;	
	}
	else if(led_put_counter < 370)
	{
		led_duty[6] = 0;
		led_duty[7] = 370 - led_put_counter;	
	}
	else
	{
		led_duty[0] = 0;
		led_duty[1] = 0;
		led_duty[2] = 0;
		led_duty[3] = 0;
		led_duty[4] = 0;
		led_duty[5] = 0;
		led_duty[6] = 0;
		led_duty[7] = 0;		
	}
}	
