//LED�C���~�l�[�V�����p�^�[������6
//���x���Q�[�W��

#include <stdlib.h>

extern unsigned char led_duty[8];	//LED��duty��ݒ�(0�ŏ����A100�őS��)
extern int led_put_counter;


unsigned char led_pattern6_temp[8] = {0,0,0,0,0,0,0,0};
unsigned char led_pattern6_temp2[8] = {5,5,5,5,5,5,5,5};

void led_put_pattern6(void)
{
	char fi;
	led_put_counter++;
	if(led_put_counter >= 200)
		led_put_counter = 0;

	for(fi = 0;fi<8;fi++)
	{
		if(led_pattern6_temp[fi] > 100)
		{
			led_duty[fi] = 200 - led_pattern6_temp[fi];
			led_pattern6_temp[fi] -= led_pattern6_temp2[fi];
		}
		else if(led_pattern6_temp[fi] > led_pattern6_temp2[fi])
		{
			led_duty[fi] = led_pattern6_temp[fi];
			led_pattern6_temp[fi] -= led_pattern6_temp2[fi];			
		}
		else
		{
			led_pattern6_temp[fi] = 0;
			led_duty[fi] = 0;
		}
	}

	if(led_put_counter == 10)
	{
		led_pattern6_temp[7] = 200;
	}
	if(led_put_counter == 20)
	{
		led_pattern6_temp[6] = 200;
	}
	if(led_put_counter == 30)
	{
		led_pattern6_temp[5] = 200;
		led_pattern6_temp2[7] = 0;
	}
	if(led_put_counter == 40)
	{
		led_pattern6_temp[4] = 200;
		led_pattern6_temp2[6] = 0;
	}
	if(led_put_counter == 50)
	{
		led_pattern6_temp[3] = 200;
		led_pattern6_temp2[5] = 0;
	}
	if(led_put_counter == 60)
	{
		led_pattern6_temp[2] = 200;
		led_pattern6_temp2[4] = 0;
	}
	if(led_put_counter == 70)
	{
		led_pattern6_temp[1] = 200;
		led_pattern6_temp2[3] = 0;
	}
	if(led_put_counter == 80)
	{
		led_pattern6_temp[0] = 200;
		led_pattern6_temp2[2] = 0;
	}
	if(led_put_counter == 90)
	{
		led_pattern6_temp2[1] = 0;
	}
	if(led_put_counter == 100)
	{
		led_pattern6_temp2[1] = 5;
	}
	if(led_put_counter == 110)
	{
		led_pattern6_temp2[2] = 5;
	}
	if(led_put_counter == 120)
	{
		led_pattern6_temp2[3] = 5;
	}
	if(led_put_counter == 130)
	{
		led_pattern6_temp2[4] = 5;
	}
	if(led_put_counter == 140)
	{
		led_pattern6_temp2[5] = 5;
	}
	if(led_put_counter == 150)
	{
		led_pattern6_temp2[6] = 5;
	}
	if(led_put_counter == 160)
	{
		led_pattern6_temp2[7] = 5;
	}
}
