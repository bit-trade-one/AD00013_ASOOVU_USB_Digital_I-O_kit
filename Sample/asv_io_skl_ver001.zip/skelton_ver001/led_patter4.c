//LED�C���~�l�[�V�����p�^�[������4
//�^�񒆂��獶�E�ɍL����

#include <stdlib.h>

extern unsigned char led_duty[8];	//LED��duty��ݒ�(0�ŏ����A100�őS��)
extern int led_put_counter;


unsigned char led_pattern4_temp[8] = {0,0,0,0,0,0,0,0};
unsigned char led_pattern4_temp2[8] = {1,1,1,1,1,1,1,1};

void led_put_pattern4(void)
{
	char fi;
	led_put_counter++;
	if(led_put_counter >= 300)
		led_put_counter = 0;

	for(fi = 0;fi<8;fi++)
	{
		if(led_pattern4_temp[fi] > 100)
		{
			led_duty[fi] = 200 - led_pattern4_temp[fi];
			led_pattern4_temp[fi] -= led_pattern4_temp2[fi];
		}
		else if(led_pattern4_temp[fi] > led_pattern4_temp2[fi])
		{
			led_duty[fi] = led_pattern4_temp[fi];
			led_pattern4_temp[fi] -= led_pattern4_temp2[fi];			
		}
		else
		{
			led_pattern4_temp[fi] = 0;
			led_duty[fi] = 0;
		}
	}

	if(led_put_counter == 10)
	{
		led_pattern4_temp[3] = 200;
		led_pattern4_temp[4] = 200;
	}
	if(led_put_counter == 50)
	{
		led_pattern4_temp[2] = 200;
		led_pattern4_temp[5] = 200;
	}
	if(led_put_counter == 90)
	{
		led_pattern4_temp[1] = 200;
		led_pattern4_temp[6] = 200;
	}
	if(led_put_counter == 130)
	{
		led_pattern4_temp[0] = 200;
		led_pattern4_temp[7] = 200;
	}
}
