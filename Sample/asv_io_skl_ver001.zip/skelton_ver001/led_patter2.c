//LED�C���~�l�[�V�����p�^�[������2
//�e�X���e�X�̃y�[�X�œ_��

extern unsigned char led_duty[8];	//LED��duty��ݒ�(0�ŏ����A100�őS��)
extern unsigned int led_put_counter;


unsigned char led_pattern2_temp[8] = {0,0,0,0,0,0,0,0};
unsigned char led_pattern2_temp2[8] = {1,1,1,1,1,1,1,1};


void led_put_pattern2(void)
{
	char fi;
	char temp;

	led_put_counter++;
	if(led_put_counter > 10000)
		led_put_counter = 0;
		
	for(fi = 0;fi<8;fi++)
	{
		if(led_pattern2_temp[fi] > 100)
		{
			led_duty[fi] = 200 - led_pattern2_temp[fi];
			led_pattern2_temp[fi] -= led_pattern2_temp2[fi];
		}
		else if(led_pattern2_temp[fi] > led_pattern2_temp2[fi])
		{
			led_duty[fi] = led_pattern2_temp[fi];
			led_pattern2_temp[fi] -= led_pattern2_temp2[fi];			
		}
		else
		{
			led_pattern2_temp[fi] = 0;
			led_duty[fi] = 0;
		}
	}

	if((led_put_counter % 250) == 0)
	{
		led_pattern2_temp[0] = 200;
		led_pattern2_temp2[0] = (led_put_counter % 11);
	}
	if((led_put_counter % 280) == 0)
	{
		led_pattern2_temp[1] = 200;
		led_pattern2_temp2[1] = (led_put_counter % 9);
	}
	if((led_put_counter % 220) == 0)
	{
		led_pattern2_temp[2] = 200;
		led_pattern2_temp2[2] = (led_put_counter % 7);
	}
	if((led_put_counter % 230) == 0)
	{
		led_pattern2_temp[3] = 200;
		led_pattern2_temp2[3] = (led_put_counter % 13);
	}
	if((led_put_counter % 350) == 0)
	{
		led_pattern2_temp[4] = 200;
		led_pattern2_temp2[4] = (led_put_counter % 17);
	}
	if((led_put_counter % 300) == 0)
	{
		led_pattern2_temp[5] = 200;
		led_pattern2_temp2[5] = (led_put_counter % 7);
	}
	if((led_put_counter % 240) == 0)
	{
		led_pattern2_temp[6] = 200;
		led_pattern2_temp2[6] = (led_put_counter % 13);
	}
	if((led_put_counter % 270) == 0)
	{
		led_pattern2_temp[7] = 200;
		led_pattern2_temp2[7] = (led_put_counter % 11);
	}
}
