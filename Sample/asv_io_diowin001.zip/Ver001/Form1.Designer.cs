namespace HID_PnP_Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.FormUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.ToggleLEDToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.PushbuttonStateTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.input_tb1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.output_cb8 = new System.Windows.Forms.CheckBox();
            this.output_cb7 = new System.Windows.Forms.CheckBox();
            this.output_cb6 = new System.Windows.Forms.CheckBox();
            this.output_cb5 = new System.Windows.Forms.CheckBox();
            this.output_cb4 = new System.Windows.Forms.CheckBox();
            this.output_cb3 = new System.Windows.Forms.CheckBox();
            this.output_cb2 = new System.Windows.Forms.CheckBox();
            this.output_cb1 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.input_tb10 = new System.Windows.Forms.TextBox();
            this.input_tb9 = new System.Windows.Forms.TextBox();
            this.input_tb8 = new System.Windows.Forms.TextBox();
            this.input_tb7 = new System.Windows.Forms.TextBox();
            this.input_tb6 = new System.Windows.Forms.TextBox();
            this.input_tb5 = new System.Windows.Forms.TextBox();
            this.input_tb4 = new System.Windows.Forms.TextBox();
            this.input_tb3 = new System.Windows.Forms.TextBox();
            this.input_tb2 = new System.Windows.Forms.TextBox();
            this.connect_status_lbl = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // FormUpdateTimer
            // 
            this.FormUpdateTimer.Enabled = true;
            this.FormUpdateTimer.Interval = 6;
            this.FormUpdateTimer.Tick += new System.EventHandler(this.FormUpdateTimer_Tick);
            // 
            // ToggleLEDToolTip
            // 
            this.ToggleLEDToolTip.AutomaticDelay = 2000;
            this.ToggleLEDToolTip.AutoPopDelay = 20000;
            this.ToggleLEDToolTip.InitialDelay = 15;
            this.ToggleLEDToolTip.ReshowDelay = 15;
            // 
            // PushbuttonStateTooltip
            // 
            this.PushbuttonStateTooltip.AutomaticDelay = 20;
            this.PushbuttonStateTooltip.AutoPopDelay = 20000;
            this.PushbuttonStateTooltip.InitialDelay = 15;
            this.PushbuttonStateTooltip.ReshowDelay = 15;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 2000;
            this.toolTip1.AutoPopDelay = 20000;
            this.toolTip1.InitialDelay = 15;
            this.toolTip1.ReshowDelay = 15;
            // 
            // toolTip2
            // 
            this.toolTip2.AutomaticDelay = 20;
            this.toolTip2.AutoPopDelay = 20000;
            this.toolTip2.InitialDelay = 15;
            this.toolTip2.ReshowDelay = 15;
            // 
            // input_tb1
            // 
            this.input_tb1.Enabled = false;
            this.input_tb1.Location = new System.Drawing.Point(48, 33);
            this.input_tb1.Name = "input_tb1";
            this.input_tb1.Size = new System.Drawing.Size(49, 19);
            this.input_tb1.TabIndex = 28;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.output_cb8);
            this.groupBox1.Controls.Add(this.output_cb7);
            this.groupBox1.Controls.Add(this.output_cb6);
            this.groupBox1.Controls.Add(this.output_cb5);
            this.groupBox1.Controls.Add(this.output_cb4);
            this.groupBox1.Controls.Add(this.output_cb3);
            this.groupBox1.Controls.Add(this.output_cb2);
            this.groupBox1.Controls.Add(this.output_cb1);
            this.groupBox1.Location = new System.Drawing.Point(51, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(81, 241);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "�o��";
            // 
            // output_cb8
            // 
            this.output_cb8.AutoSize = true;
            this.output_cb8.Location = new System.Drawing.Point(22, 210);
            this.output_cb8.Name = "output_cb8";
            this.output_cb8.Size = new System.Drawing.Size(38, 16);
            this.output_cb8.TabIndex = 7;
            this.output_cb8.Text = "O8";
            this.output_cb8.UseVisualStyleBackColor = true;
            this.output_cb8.CheckedChanged += new System.EventHandler(this.output_cb8_CheckedChanged);
            // 
            // output_cb7
            // 
            this.output_cb7.AutoSize = true;
            this.output_cb7.Location = new System.Drawing.Point(22, 185);
            this.output_cb7.Name = "output_cb7";
            this.output_cb7.Size = new System.Drawing.Size(38, 16);
            this.output_cb7.TabIndex = 6;
            this.output_cb7.Text = "O7";
            this.output_cb7.UseVisualStyleBackColor = true;
            this.output_cb7.CheckedChanged += new System.EventHandler(this.output_cb7_CheckedChanged);
            // 
            // output_cb6
            // 
            this.output_cb6.AutoSize = true;
            this.output_cb6.Location = new System.Drawing.Point(22, 160);
            this.output_cb6.Name = "output_cb6";
            this.output_cb6.Size = new System.Drawing.Size(38, 16);
            this.output_cb6.TabIndex = 5;
            this.output_cb6.Text = "O6";
            this.output_cb6.UseVisualStyleBackColor = true;
            this.output_cb6.CheckedChanged += new System.EventHandler(this.output_cb6_CheckedChanged);
            // 
            // output_cb5
            // 
            this.output_cb5.AutoSize = true;
            this.output_cb5.Location = new System.Drawing.Point(22, 135);
            this.output_cb5.Name = "output_cb5";
            this.output_cb5.Size = new System.Drawing.Size(38, 16);
            this.output_cb5.TabIndex = 4;
            this.output_cb5.Text = "O5";
            this.output_cb5.UseVisualStyleBackColor = true;
            this.output_cb5.CheckedChanged += new System.EventHandler(this.output_cb5_CheckedChanged);
            // 
            // output_cb4
            // 
            this.output_cb4.AutoSize = true;
            this.output_cb4.Location = new System.Drawing.Point(22, 110);
            this.output_cb4.Name = "output_cb4";
            this.output_cb4.Size = new System.Drawing.Size(38, 16);
            this.output_cb4.TabIndex = 3;
            this.output_cb4.Text = "O4";
            this.output_cb4.UseVisualStyleBackColor = true;
            this.output_cb4.CheckedChanged += new System.EventHandler(this.output_cb4_CheckedChanged);
            // 
            // output_cb3
            // 
            this.output_cb3.AutoSize = true;
            this.output_cb3.Location = new System.Drawing.Point(22, 85);
            this.output_cb3.Name = "output_cb3";
            this.output_cb3.Size = new System.Drawing.Size(38, 16);
            this.output_cb3.TabIndex = 2;
            this.output_cb3.Text = "O3";
            this.output_cb3.UseVisualStyleBackColor = true;
            this.output_cb3.CheckedChanged += new System.EventHandler(this.output_cb3_CheckedChanged);
            // 
            // output_cb2
            // 
            this.output_cb2.AutoSize = true;
            this.output_cb2.Location = new System.Drawing.Point(22, 60);
            this.output_cb2.Name = "output_cb2";
            this.output_cb2.Size = new System.Drawing.Size(38, 16);
            this.output_cb2.TabIndex = 1;
            this.output_cb2.Text = "O2";
            this.output_cb2.UseVisualStyleBackColor = true;
            this.output_cb2.CheckedChanged += new System.EventHandler(this.output_cb2_CheckedChanged);
            // 
            // output_cb1
            // 
            this.output_cb1.AutoSize = true;
            this.output_cb1.Location = new System.Drawing.Point(22, 35);
            this.output_cb1.Name = "output_cb1";
            this.output_cb1.Size = new System.Drawing.Size(38, 16);
            this.output_cb1.TabIndex = 0;
            this.output_cb1.Text = "O1";
            this.output_cb1.UseVisualStyleBackColor = true;
            this.output_cb1.CheckedChanged += new System.EventHandler(this.output_cb1_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.input_tb8);
            this.groupBox2.Controls.Add(this.input_tb7);
            this.groupBox2.Controls.Add(this.input_tb6);
            this.groupBox2.Controls.Add(this.input_tb5);
            this.groupBox2.Controls.Add(this.input_tb4);
            this.groupBox2.Controls.Add(this.input_tb3);
            this.groupBox2.Controls.Add(this.input_tb2);
            this.groupBox2.Controls.Add(this.input_tb1);
            this.groupBox2.Location = new System.Drawing.Point(445, 47);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(113, 252);
            this.groupBox2.TabIndex = 35;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "����";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // input_tb10
            // 
            this.input_tb10.Enabled = false;
            this.input_tb10.Location = new System.Drawing.Point(224, 346);
            this.input_tb10.Name = "input_tb10";
            this.input_tb10.Size = new System.Drawing.Size(55, 19);
            this.input_tb10.TabIndex = 37;
            // 
            // input_tb9
            // 
            this.input_tb9.Enabled = false;
            this.input_tb9.Location = new System.Drawing.Point(287, 346);
            this.input_tb9.Name = "input_tb9";
            this.input_tb9.Size = new System.Drawing.Size(52, 19);
            this.input_tb9.TabIndex = 36;
            // 
            // input_tb8
            // 
            this.input_tb8.Enabled = false;
            this.input_tb8.Location = new System.Drawing.Point(48, 208);
            this.input_tb8.Name = "input_tb8";
            this.input_tb8.Size = new System.Drawing.Size(49, 19);
            this.input_tb8.TabIndex = 35;
            // 
            // input_tb7
            // 
            this.input_tb7.Enabled = false;
            this.input_tb7.Location = new System.Drawing.Point(48, 183);
            this.input_tb7.Name = "input_tb7";
            this.input_tb7.Size = new System.Drawing.Size(49, 19);
            this.input_tb7.TabIndex = 34;
            // 
            // input_tb6
            // 
            this.input_tb6.Enabled = false;
            this.input_tb6.Location = new System.Drawing.Point(48, 158);
            this.input_tb6.Name = "input_tb6";
            this.input_tb6.Size = new System.Drawing.Size(49, 19);
            this.input_tb6.TabIndex = 33;
            // 
            // input_tb5
            // 
            this.input_tb5.Enabled = false;
            this.input_tb5.Location = new System.Drawing.Point(48, 133);
            this.input_tb5.Name = "input_tb5";
            this.input_tb5.Size = new System.Drawing.Size(49, 19);
            this.input_tb5.TabIndex = 32;
            // 
            // input_tb4
            // 
            this.input_tb4.Enabled = false;
            this.input_tb4.Location = new System.Drawing.Point(48, 108);
            this.input_tb4.Name = "input_tb4";
            this.input_tb4.Size = new System.Drawing.Size(49, 19);
            this.input_tb4.TabIndex = 31;
            // 
            // input_tb3
            // 
            this.input_tb3.Enabled = false;
            this.input_tb3.Location = new System.Drawing.Point(48, 83);
            this.input_tb3.Name = "input_tb3";
            this.input_tb3.Size = new System.Drawing.Size(49, 19);
            this.input_tb3.TabIndex = 30;
            // 
            // input_tb2
            // 
            this.input_tb2.Enabled = false;
            this.input_tb2.Location = new System.Drawing.Point(48, 58);
            this.input_tb2.Name = "input_tb2";
            this.input_tb2.Size = new System.Drawing.Size(49, 19);
            this.input_tb2.TabIndex = 29;
            // 
            // connect_status_lbl
            // 
            this.connect_status_lbl.AutoSize = true;
            this.connect_status_lbl.Location = new System.Drawing.Point(12, 403);
            this.connect_status_lbl.Name = "connect_status_lbl";
            this.connect_status_lbl.Size = new System.Drawing.Size(41, 12);
            this.connect_status_lbl.TabIndex = 26;
            this.connect_status_lbl.Text = "���ڑ�";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(137, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(284, 287);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 36;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 12);
            this.label1.TabIndex = 36;
            this.label1.Text = "SW1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 12);
            this.label2.TabIndex = 37;
            this.label2.Text = "SW2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 12);
            this.label3.TabIndex = 38;
            this.label3.Text = "SW3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 12);
            this.label4.TabIndex = 39;
            this.label4.Text = "SW4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 12);
            this.label5.TabIndex = 40;
            this.label5.Text = "SW5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 12);
            this.label6.TabIndex = 41;
            this.label6.Text = "SW6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 186);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 12);
            this.label7.TabIndex = 42;
            this.label7.Text = "SW7";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 211);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 12);
            this.label8.TabIndex = 43;
            this.label8.Text = "SW8";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(285, 333);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(27, 12);
            this.label9.TabIndex = 44;
            this.label9.Text = "SW9";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(245, 333);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(33, 12);
            this.label10.TabIndex = 45;
            this.label10.Text = "SW10";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 424);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.input_tb10);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.input_tb9);
            this.Controls.Add(this.connect_status_lbl);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form1";
            this.Text = "ASOOVU USB �f�W�^�����o�̓T���v��";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.Timer FormUpdateTimer;
        private System.Windows.Forms.ToolTip ToggleLEDToolTip;
        private System.Windows.Forms.ToolTip PushbuttonStateTooltip;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.TextBox input_tb1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox output_cb8;
        private System.Windows.Forms.CheckBox output_cb7;
        private System.Windows.Forms.CheckBox output_cb6;
        private System.Windows.Forms.CheckBox output_cb5;
        private System.Windows.Forms.CheckBox output_cb4;
        private System.Windows.Forms.CheckBox output_cb3;
        private System.Windows.Forms.CheckBox output_cb2;
        private System.Windows.Forms.CheckBox output_cb1;
        private System.Windows.Forms.TextBox input_tb10;
        private System.Windows.Forms.TextBox input_tb9;
        private System.Windows.Forms.TextBox input_tb8;
        private System.Windows.Forms.TextBox input_tb7;
        private System.Windows.Forms.TextBox input_tb6;
        private System.Windows.Forms.TextBox input_tb5;
        private System.Windows.Forms.TextBox input_tb4;
        private System.Windows.Forms.TextBox input_tb3;
        private System.Windows.Forms.TextBox input_tb2;
        private System.Windows.Forms.Label connect_status_lbl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}

