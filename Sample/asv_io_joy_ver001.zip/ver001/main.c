/*
	PIC18F2550 �����`��USB�p�f�W�^�����o�̓L�b�g�p����������T���v��
		ver1.00	2011/06/15	����

	10�{�^���Ƃ��ĔF������܂��B
	������������1�`8�̑��������ꂽ���̂��������ςȂ��ɂȂ�܂��B

	S9�^S10�ŃX�^�[�g�^���Z�b�g
*/

#ifndef JOYSTICKMAIN_C
#define JOYSTICKMAIN_C

/** INCLUDES *******************************************************/
#include "Microchip/Include/USB/usb.h"
#include "HardwareProfile.h"
#include "Microchip/Include/USB/usb_function_hid.h"
#include "bootload.h"
#include "asv_io.h"


/** PRIVATE PROTOTYPES *********************************************/
static void InitializeSystem(void);
void ProcessIO(void);
void UserInit(void);
void Joystick(void);

/** VARIABLES ******************************************************/
#pragma udata
char buffer[8];
USB_HANDLE lastTransmission;
BOOL Keyboard_out;

#define STATUS_RESET	0
#define STATUS_WAIT_PUSH	1
#define STATUS_HOLD_PUSH	2
unsigned char status = STATUS_RESET;
unsigned char button_push = 0;
unsigned char button_push2 = 0;
unsigned char button_push2_pre = 0;
unsigned char button_hold = 0;


BYTE joystick_buffer[2];

#pragma udata USB_VARIABLES=0x500
BYTE joystick_input[2];
BYTE hid_report[8];
#pragma udata


#pragma code
void isr_high()
{
	#if defined(USB_INTERRUPT)
	USBDeviceTasks();
	#endif
}	//This return will be a "retfie fast", since this is in a #pragma interrupt section 
void isr_low()
{
}	//This return will be a "retfie", since this is in a #pragma interruptlow section 


/********************************************************************
 * Function:        void main(void)
 *******************************************************************/
void main(void)
{   
    InitializeSystem();

    #if defined(USB_INTERRUPT)
        USBDeviceAttach();
    #endif

    while(1)
    {
        #if defined(USB_POLLING)
        USBDeviceTasks(); // Interrupt or polling method.  If using polling, must call
        #endif
    				  
        ProcessIO();        
    }//end while
}//end main


/********************************************************************
 * Function:        static void InitializeSystem(void)
 *******************************************************************/
static void InitializeSystem(void)
{

    #if defined(USE_USB_BUS_SENSE_IO)
    tris_usb_bus_sense = INPUT_PIN; // See HardwareProfile.h
    #endif
    
    #if defined(USE_SELF_POWER_SENSE_IO)
    tris_self_power = INPUT_PIN;	// See HardwareProfile.h
    #endif
    
    UserInit();

    USBDeviceInit();	//usb_device.c.  Initializes USB module SFRs and firmware
}//end InitializeSystem



/******************************************************************************
 * Function:        void UserInit(void)
 *****************************************************************************/
void UserInit(void)
{
	asv_io_init();
	
	joystick_input[0] = 0x00;
	joystick_input[1] = 0x00;

    joystick_buffer[0] = 0;
    joystick_buffer[1] = 0;

    lastTransmission = 0;
}//end UserInit


/********************************************************************
 * Function:        void ProcessIO(void)
 *******************************************************************/
void ProcessIO(void)
{   
    // User Application USB tasks
    if((USBDeviceState < CONFIGURED_STATE)||(USBSuspendControl==1)) return;

   Joystick();
}//end ProcessIO


/******************************************************************************
 * Function:        void Joystick(void)
 *****************************************************************************/
void Joystick(void)
{
	button_push |= !asv_io_get_SW(1);
	button_push |= ((!asv_io_get_SW(2)) << 1);
	button_push |= ((!asv_io_get_SW(3)) << 2);
	button_push |= ((!asv_io_get_SW(4)) << 3);
	button_push |= ((!asv_io_get_SW(5)) << 4);
	button_push |= ((!asv_io_get_SW(6)) << 5);
	button_push |= ((!asv_io_get_SW(7)) << 6);
	button_push |= ((!asv_io_get_SW(8)) << 7);


		
    if(!HIDTxHandleBusy(lastTransmission))
    {
		button_push2_pre = button_push2;
		button_push2 = !asv_io_get_SW(9);
		button_push2 |= ((!asv_io_get_SW(10)) << 1);
	    switch(status)
	    {
		    case STATUS_RESET:
		    //LED�S����
		    	asv_io_set_LED(1,0);
		    	asv_io_set_LED(2,0);
		    	asv_io_set_LED(3,0);
		    	asv_io_set_LED(4,0);
		    	asv_io_set_LED(5,0);
		    	asv_io_set_LED(6,0);
		    	asv_io_set_LED(7,0);
		    	asv_io_set_LED(8,0);
		    	
		    	if((button_push2 != 0) && (button_push2_pre == 0))
		    	{
			    	status = STATUS_WAIT_PUSH;
			    }
				
			    joystick_buffer[0] = button_push;
			    joystick_buffer[1] = button_push2;
		    	break;
		    case STATUS_WAIT_PUSH:
		    //LED�S�_��
		    	asv_io_set_LED(1,1);
		    	asv_io_set_LED(2,1);
		    	asv_io_set_LED(3,1);
		    	asv_io_set_LED(4,1);
		    	asv_io_set_LED(5,1);
		    	asv_io_set_LED(6,1);
		    	asv_io_set_LED(7,1);
		    	asv_io_set_LED(8,1);

				if(button_push != 0)
				{	//�ǂꂩ�ЂƂł�������Ă�����
					button_hold = button_push;
					status = STATUS_HOLD_PUSH;
				}	
			    joystick_buffer[0] = button_push;
			    joystick_buffer[1] = button_push2;
		    	break;
		    case STATUS_HOLD_PUSH:
		    	//���������ꂽLED�����_��
		    	asv_io_set_LED(1,(button_hold & 0x01) ? 1 : 0);
		    	asv_io_set_LED(2,(button_hold & 0x02) ? 1 : 0);
		    	asv_io_set_LED(3,(button_hold & 0x04) ? 1 : 0);
		    	asv_io_set_LED(4,(button_hold & 0x08) ? 1 : 0);
		    	asv_io_set_LED(5,(button_hold & 0x10) ? 1 : 0);
		    	asv_io_set_LED(6,(button_hold & 0x20) ? 1 : 0);
		    	asv_io_set_LED(7,(button_hold & 0x40) ? 1 : 0);
		    	asv_io_set_LED(8,(button_hold & 0x80) ? 1 : 0);

				if(button_push2 != 0 && button_push2_pre == 0)
				{
					status = STATUS_RESET;
				}	

		    	joystick_buffer[0] = button_hold;
		    	joystick_buffer[1] = button_push2;		    	
		    	break;
		}
	    
	    joystick_input[0] = joystick_buffer[0];
	    joystick_input[1] = joystick_buffer[1];
	    
	    joystick_buffer[0] = 0;
	    joystick_buffer[1] = 0;
	    
	    button_push = 0;
	    
      	lastTransmission = HIDTxPacket(HID_EP, (BYTE*)&joystick_input, sizeof(joystick_input));
    }
    return;		
}//end joystick()


// ******************************************************************************************************
// ************** USB Callback Functions ****************************************************************
// ******************************************************************************************************

/******************************************************************************
 * Function:        void USBCBSuspend(void)
 *****************************************************************************/
void USBCBSuspend(void)
{
}

/******************************************************************************
 * Function:        void USBCBWakeFromSuspend(void)
 *****************************************************************************/
void USBCBWakeFromSuspend(void)
{
}

/********************************************************************
 * Function:        void USBCB_SOF_Handler(void)
 *******************************************************************/
void USBCB_SOF_Handler(void)
{
}

/*******************************************************************
 * Function:        void USBCBErrorHandler(void)
 *******************************************************************/
void USBCBErrorHandler(void)
{
}


/*******************************************************************
 * Function:        void USBCBCheckOtherReq(void)
 *******************************************************************/
void USBCBCheckOtherReq(void)
{
    USBCheckHIDRequest();
}//end

/*******************************************************************
 * Function:        void USBCBStdSetDscHandler(void)
 *******************************************************************/
void USBCBStdSetDscHandler(void)
{
}//end


/*******************************************************************
 * Function:        void USBCBInitEP(void)
 *******************************************************************/
void USBCBInitEP(void)
{
    USBEnableEndpoint(HID_EP,USB_OUT_ENABLED|USB_IN_ENABLED|USB_HANDSHAKE_ENABLED|USB_DISALLOW_SETUP);
}

/********************************************************************
 * Function:        void USBCBSendResume(void)
 *******************************************************************/
void USBCBSendResume(void)
{
    static WORD delay_count;
    
    USBResumeControl = 1;                // Start RESUME signaling
    
    delay_count = 1800U;                // Set RESUME line for 1-13 ms
    do
    {
        delay_count--;
    }while(delay_count);
    USBResumeControl = 0;
}


/*******************************************************************
 * Function:        BOOL USER_USB_CALLBACK_EVENT_HANDLER(
 *******************************************************************/
BOOL USER_USB_CALLBACK_EVENT_HANDLER(USB_EVENT event, void *pdata, WORD size)
{
    switch(event)
    {
        case EVENT_CONFIGURED: 
            USBCBInitEP();
            break;
        case EVENT_SET_DESCRIPTOR:
            USBCBStdSetDscHandler();
            break;
        case EVENT_EP0_REQUEST:
            USBCBCheckOtherReq();
            break;
        case EVENT_SOF:
            USBCB_SOF_Handler();
            break;
        case EVENT_SUSPEND:
            USBCBSuspend();
            break;
        case EVENT_RESUME:
            USBCBWakeFromSuspend();
            break;
        case EVENT_BUS_ERROR:
            USBCBErrorHandler();
            break;
        case EVENT_TRANSFER:
            Nop();
            break;
        default:
            break;
    }      
    return TRUE; 
}

/** EOF main.c *************************************************/
#endif
